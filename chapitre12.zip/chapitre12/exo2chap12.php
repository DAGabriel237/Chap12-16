
<?php
if(isset($_POST['col_txt']) && isset($_POST['col_fnd'])){
    $col_txt=$_POST['col_txt'];
    $col_fnd=$_POST['col_fnd'];
    setcookie("couleur[col_texte]",$col_txt);
    setcookie("couleur[col_fond]",$col_fnd);
    
}
?>
<?php
$cookie1 =$_COOKIE['couleur']['col_texte'];
$cookie2 =$_COOKIE['couleur']['col_fond'];
echo $cookie2;
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
   
</head>
<body>
<form  method="post" onload="mk_chng()">
<label> couleur de texte <label>
<input type="text" id="col_txt" name="col_txt" placeholder="votre couleur de texte ici"><br>
<label> couleur de fond <label>
<input type="text" id="col_fnd" name="col_fnd" placeholder="votre couleur de fond ici"><br>
<input type="submit" value="submit">
</form>
<script>
    alert("bbbbbbbbbbbb");
    document.getElementById("col_fnd").style.backgroundColor="<?php echo  $cookie2 ?>";
    document.getElementById("col_txt").style.color="<?php echo $cookie1 ?>";

</script>
</body>
</html>


