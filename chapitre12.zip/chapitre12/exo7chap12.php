<?php
session_start();
echo $_POST['fond'];
$_SESSION['fond'] =$_POST['fond'];
$_SESSION['texte'] =$_POST['texte'];
$fond=$_SESSION['fond'];
$texte=$_SESSION['texte'];
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-
8859-1" />
<title>Couleurs du site avec des sessions</title>
<style type="text/css" >

body{background-color: <?php echo $fond ?> ; color: <?php echo
$texte ?> ;}
legend{font-weight:bold;font-family:cursive;}
label{font-weight:bold;font-style:italic;}

</style>
</head>
<body>
<p>Contenu de la page B
<a href="exo7partachap12.html">Lien vers la page principale</a>
</p>
</body>
</html>