<?php
$tabmailA=array("adg@gmail.com","le stage a commence","commence ton stage ");
$tabmailB=array("amangdanidio@gmail.com.com","microsoft access","La base de données
évolue");
$tabmailC=array("amanggabriel6@gmail.com","1 ans de plus ","hbd bro ");
$tabmail=array($tabmailA,$tabmailB,$tabmailC);
foreach($tabmail as $tab)
{
if(mail($tab[0],$tab[1],$tab[2]))
{
echo "Mail envoyé à $tab[0]";
}
else{
    echo "echec";
}
}
?>