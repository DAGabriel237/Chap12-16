<?php
$tabmailadresse=array("amanglora@gmail.com","amanggabriel6@gmail.com");
$objet="Message";
$message="Bonjour de mon ami";
foreach($tabmailadresse as $dest)
{
if(mail($dest,$objet,$message))
{
echo "Mail envoyé à $dest";
}
else{
    echo "echec";
}
}
?>