<?php
//if(isset($_COOKIE['nom']) AND isset($_COOKIE['pass']))
//{
$login="admin";
$motpass="admin";

//Vérification et création du contenu personnalisé

if(isset($_POST['nom']) && isset($_POST['pass'])){
    $name=$_POST['nom'];
    $passwd=$_POST['pass'];
   
    if($name==$login AND $passwd==$motpass)
{
echo "connection reussie";
setcookie("nom",$name);
setcookie("pass",$passwd);
//$nom=$_COOKIE['nom'];
//$pass=$_COOKIE['pass'];
//header('Location::');
}
else
{
echo "echec connection ";
}

}
//}
?>
<!DOCTYPE html PUBLIC>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-
8859-1" />
<title>Accès réservé au site</title>
</head>
<body>
<form method="post" >
<fieldset>
<legend>Saisissez votre nom et mot de passe</legend>
<label>Nom :
<input type="text" name="nom" value="<?php if(isset($_COOKIE['nom']) AND isset($_COOKIE['pass'])){
    echo $_COOKIE['nom'];
} ?>" />
</label><br /><br />
<label>Pass :
<input type="text" name="pass" value="<?php if(isset($_COOKIE['nom']) AND isset($_COOKIE['pass'])){
    echo $_COOKIE['pass'];
} ?>" />
</label><br />
<input type="submit" value="Envoyer" />&nbsp;&nbsp;
<input type="reset" value="Effacer" />
</fieldset>
</form>
</body>
</html>