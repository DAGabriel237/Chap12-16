<?php
//Détection du cookie et redirection éventuelle vers la page
if(isset($_POST['mapage']))
{
setcookie("mapage",$_POST['mapage'],time()+10);
header("Location:$page");echo "Vous avez choisi ",$_POST['mapage'],"<br />";
echo $_COOKIE["mapage"];
}
if(isset($_COOKIE['mapage']))
{
$page=$_COOKIE['mapage'];
header("Location:$page");
echo $_COOKIE["mapage"];
}
//

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-
8859-1" />
<title>Choisissez votre page préférée</title>
</head>
<body>
<form method="post">
<fieldset>
<legend>Choisissez votre page préférée</legend>
<select name="mapage">
<option value="exo2chap12.php">Exercice 1</option>
<option value="exo2chap12.php">Exercice 2</option>
</select>
<br />
<input type="submit" value="Envoyer" />&nbsp;&nbsp;
<input type="reset" value="Effacer" />
</fieldset>
</form>
</body>
</html>
