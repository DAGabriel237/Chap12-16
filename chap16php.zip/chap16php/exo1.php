<?php
try{
    //include_once("myparam.inc.php");
$user="root";
$passwd="";
$host="localhost";
$db="voitures";
$idcom= new PDO("mysql:host=$host;dbname=$db",$user,$passwd) ;
if(!$idcom)
{
echo "Erreur";
}
else{
    echo "coool";
    $sth = $idcom->prepare("SELECT *  FROM  model");
$sth->execute();

/* Fetch all of the remaining rows in the result set */
//print("Fetch all of the remaining rows in the result set:\n");
$result = $sth->fetchAll();

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        print_r($result);
}
}catch(Exception $e){
    echo 'Caught exception: ',  $e->getMessage(), "\n";

}

//***********
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <script src="main.js"></script>
</head>
<body>
    <table>
    <tr>
    <td></td>
    <td></td>
    </tr>
    
    <?php
    try{
        echo "cool";
        $response = $idcom->prepare("SELECT *  FROM  model");
        $response->execute();
        $response->bindColumn('nom_type', $nom);
        $response->bindColumn('numero_type', $numero);
      //  numero_type
      //  $donnees=$response->fetch(PDO::FETCH_BOUND);
       // echo "$donnees";
   
       while ($donnees=$response->fetch(PDO::FETCH_BOUND)){
           echo "<tr>"."<td>".$nom."</td>"."<td>".$numero."</td>"."</tr>";
           
           } 
  
   $response->closeCursor();
    }catch(Exception $e){
        $e->getMessage();
    }
    
    ?>
    
    </table>
</body>
</html>

