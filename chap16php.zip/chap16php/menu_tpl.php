<div>
	<h2>MENU</h2>
	<ul>
		<li><a href="exo1.php">Exercice 1</a></li>
		<li><a href="exo2.php">Exercice 2</a></li>
		<li><a href="exo3.php">Exercice 3</a></li>
		<li><a href="exo4.php">Exercice 4</a></li>
		<li><a href="exo5.php">Exercice 5</a></li>
		<li><a href="exo6.php">Exercice 6</a></li>
		<li><a href="exo4.php">Exercice 7</a></li>
		<li><a href="exo8.php">Exercice 8</a></li>
	</ul>
</div>
