<?php
if(isset($_POST['num_mod'])&&isset($_POST['mod_type'])){
    try {
        $db="voitures";
$host="localhost";
$user="root";
$passwd="";
$num_model=$_POST['num_mod'];
$mod_type=$_POST['mod_type'];
$cnx= new PDO("mysql:host=$host;dbname=$db",$user,$passwd);
$request=$cnx->prepare("insert into model values(:numero_type,:nom_type)");
$request->execute([
        'numero_type'=>$num_model,
       'nom_type'=>$mod_type]);
$request->closeCursor();
    } catch (Exception $e) {
        //throw $th;
        $e->getMessage();
    }


}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <script src="main.js"></script>
</head>
<body>
    <fieldset>
    <legend>
    insert in model table
    </legend>
    <form method='post'>
    <label for="num_mod">Numero de Model</label>
    <input type="text" name="num_mod" id="num_mod">
    <label for="mod_type">Type de model</label>
    <input type="text" name="mod_type" id="mod_type">
    <input type="submit" value="Insert">
    </form>
    </fieldset>
</body>
</html>